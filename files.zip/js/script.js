$(document).ready(function() {
    console.log("Document is ready");

    $("#morebtn").click(function() {
        $("#more").slideToggle();
    });

    $("#theform").submit(function (e) {
        e.preventDefault(); // Prevent the form from submitting the traditional way
        console.log("Form submitted");

        const query = $("#q").val();
        const maxResults = $("#max").val();
        const order = $("#sort").val();
        const apiKey = 'AIzaSyBLsXf9h1AHqCMxKggbRVy9wD16QbZTBUE'; // Your YouTube API key

        if (query) {
            console.log("Searching for:", query);
            fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=${maxResults}&q=${query}&order=${order}&key=${apiKey}`)
                .then(response => response.json())
                .then(data => {
                    console.log("Data received:", data);
                    const videos = data.items;
                    $("#videos").empty();

                    if (videos.length > 0) {
                        videos.forEach(video => {
                            const videoId = video.id.videoId;
                            const title = video.snippet.title;
                            const description = video.snippet.description;
                            const thumbnail = video.snippet.thumbnails.high.url;

                            const videoHtml = `
                                <div class="video">
                                    <h3>${title}</h3>
                                    <a href="https://www.youtube.com/watch?v=${videoId}" target="_blank">
                                        <img src="${thumbnail}" alt="${title}">
                                    </a>
                                    <p>${description}</p>
                                </div>
                            `;

                            $("#videos").append(videoHtml);
                        });
                    } else {
                        $("#videos").append("<p>No videos found.</p>");
                    }
                })
                .catch(error => {
                    console.error('Error fetching YouTube videos:', error);
                });
        } else {
            console.log("Query is empty");
        }
    });
});